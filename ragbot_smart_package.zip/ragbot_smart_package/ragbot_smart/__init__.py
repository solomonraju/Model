"""
ragbot_smart package
"""
from .app import RAGBotGUI

def main():
    # Launch the Tkinter app
    app = RAGBotGUI()
    app.mainloop()
