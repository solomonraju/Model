# ragbot-smart

A Tkinter RAG bot that answers from your **documents** and the **internet** with a modern sidebar,
India/UK time cards, and a "Smart Final Answer".

## Quick start (installable package)
```bash
pip install .
ragbot-smart
```

## Run without installing
```bash
python -m ragbot_smart
```

## App assets (images / documents)
By default the app looks for assets in:
- `./venv/documents` (preferred)
- `./documents` (fallback)

Put your files here (create the folders if missing):
```
documents/
  profile.jpg      # avatar
  india.jpg        # India flag
  uk.png           # UK flag
  ... any PDFs, DOCX, TXT, CSV, XLSX you want indexed ...
```

## Build a single-file EXE (no Python needed on target PC)

**Windows (PowerShell or cmd):**
```bat
pip install pyinstaller
pyinstaller --noconfirm --onefile --windowed ^
  --name RAGBOT_Smart ^
  --add-data "documents;documents" ^
  -p . ^
  -i NONE ^
  -y ^
  -F ^
  -w ^
  -s ^
  -m ^
  -c ^
  -r ^
  -d ^
  -x ^
  -u ^
  -Y ^
  -a ^
  -j 1 ^
  -O ^
  -i NONE ^
  -n RAGBOT_Smart ^
  -p ragbot_smart ^
  ragbot_smart/app.py
```

Or simply run the provided `build_exe.bat`.

**macOS / Linux:**
```bash
pip install pyinstaller
pyinstaller --noconfirm --onefile --windowed       --name RAGBOT_Smart       --add-data "documents:documents"       ragbot_smart/app.py
```

The generated binary will be under `dist/`. Copy the binary and a `documents/` folder next to it
if you want to ship default images and files.

### Tesseract note
OCR requires the Tesseract binary installed on the machine (`pytesseract` is just a wrapper).
If OCR isn't needed, you can omit `pytesseract` from requirements.

## Developer
- Entry point: `ragbot_smart:main`
- Module: `ragbot_smart/app.py` (Tkinter GUI)
