#!/usr/bin/env bash
set -euo pipefail
pip install --upgrade pyinstaller
mkdir -p documents
pyinstaller --noconfirm --onefile --windowed       --name RAGBOT_Smart       --add-data "documents:documents"       ragbot_smart/app.py
echo "Build complete. See dist/"
